import { Component } from '@angular/core';



import{AddPostPage} from '../add-post/add-post';
import{ProfilePage} from '../profile/profile';
@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = "FeedPage";
  tab2Root = "AddPostPage";// se eu por o AddPostPage sem aspas ele entende como sendo uma variável, e com aspas ele entende como uma String
  tab3Root = "ProfilePage";

  constructor() {

  }
}
