import { Component } from '@angular/core';
import { NavController, AlertController  } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
 result: any;
  va: any;
  vg: any;

  constructor(public navCtrl: NavController,public alertCtrl: AlertController) {

  }

  calcular() {

    //Alcool/Gasolina 
      var res = this.va / this.vg;
    //se o resultado <0,7 
    if(res < 0.7){
      //retonar alcool
      console.log("alcool");
      this.showAlert('ALCOOL');
      //this.result = "ALCOOLLL";
    }else{
      // se nao retorna gasolina.
      console.log("gasolina");
      this.showAlert('GASOLINA');
     // this.result ="gasolina";
    }
  }
  showAlert(titulo) {
    const alert = this.alertCtrl.create({
      title: titulo,
      subTitle: 'Será mais economico se você abastecer com '+ titulo +'!',
      buttons: ['OK']
    });
    alert.present();
  }

}
