import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';

/*
  Generated class for the NotasProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class NotasProvider {

  constructor(public storage: Storage) {
    console.log('Hello NotasProvider Provider');
  }
  key: string = "notas";

  adicionarNota(value){
//saber se tem anuncios no banco de dados
this.storage.get(this.key)
  .then(resultado => {
    console.log(resultado);
//se não tiver notas
    if(resultado ==null){
      //inserir a primeira nota em formato de  array
      let new_value = [value];
      this.storage.set(this.key, new_value);

    }else{
      //se ja tiver notas, inserir a nova nota no array notas.
      let new_value = resultado;
      new_value.push(value);
      this.storage.set(this.key, new_value);
    }
});
   
  }

  listaNotas(){
   return this.storage.get(this.key);
  }

  editarNotas(value){
    this.storage.get(this.key)
    .then(resultado => {
      console.log(resultado)
       });    
  }

}  

  

  




