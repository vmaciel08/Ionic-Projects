import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { NotasProvider } from '../../providers/notas/notas';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  notas: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, 
    public notaService: NotasProvider) {
  }
//só executado uma vez quando a pagina é carregada
  ionViewDidEnter() {
    console.log('ionViewDidEnter HomePage');
    this.notaService.listaNotas().then(resultado =>{
      console.log(resultado);
      this.notas = resultado;
    });
    
  }

  adicionarNota() {
    this.navCtrl.push('AddNotasPage');
  }

}
