import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { NotasProvider } from '../../providers/notas/notas';
 

/**
 * Generated class for the AddNotasPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-notas',
  templateUrl: 'add-notas.html',
})
export class AddNotasPage {
  constructor(public navCtrl: NavController, public navParams: NavParams, 
    public notasService: NotasProvider, public alertCtrl: AlertController,
    ) {
  }
  
  titulo: any;
  descricao: any;
 // myDate: Date;
 
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddNotasPage');
  }
  adicionarNotas(){
    if(this.titulo == undefined
      ||this.titulo == null
      || this.titulo == ""){
      let alert = this.alertCtrl.create({
        title: 'Campo "Título" obrigatório!',
        buttons: ['OK']
      });
      alert.present();
    }else if(this.descricao == undefined
      ||this.descricao == null
      || this.descricao == ""){
      let alert = this.alertCtrl.create({
        title: 'Campo "Descrição" obrigatório!',
        buttons: ['OK']
      });
      alert.present();
    }else{
    
    var notas = {
      "titulo": this.titulo,
      "descricao": this.descricao,
     // "myDate": this.myDate
     
    };
    this.notasService.adicionarNota(notas);
    this.titulo = "";
    this.descricao = "";
    //this.myDate = "MM/YYYY";
    let alert = this.alertCtrl.create({
      title: 'Anotação Salva!',
      buttons: ['OK']
    });
    alert.present();
  }
  
}
}
  


