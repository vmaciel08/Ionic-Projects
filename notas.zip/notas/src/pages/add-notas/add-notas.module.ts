import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddNotasPage } from './add-notas';


@NgModule({
  declarations: [
    AddNotasPage,
  ],
  imports: [
    IonicPageModule.forChild(AddNotasPage),
  ],
})
export class AddNotasPageModule {
  
}


