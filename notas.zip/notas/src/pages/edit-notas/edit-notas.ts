import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the EditNotasPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-edit-notas',
  templateUrl: 'edit-notas.html',
})
export class EditNotasPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public storage: Storage) {
  }
key: string = "notas";
  ionViewDidLoad() {
    console.log('ionViewDidLoad EditNotasPage');
  }
editarNotas(){
 
  this.key = this.navParams.get('key');
  this.ref = this.af.database.object('/notas/' + this.key);
   
}
salvar(){    
  this.storage.get(this.key)
  this.storage.set(this.key).then(resultado => {
     console.log(resultado));
  }
}
deletarNotas(){

}
}