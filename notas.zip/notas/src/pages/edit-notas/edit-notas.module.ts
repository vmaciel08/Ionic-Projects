import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditNotasPage } from './edit-notas';

@NgModule({
  declarations: [
    EditNotasPage,
  ],
  imports: [
    IonicPageModule.forChild(EditNotasPage),
  ],
})
export class EditNotasPageModule {}
